import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonDollarSignParser {

    public static class User {
        @JsonProperty("$username")
        private String username;

        @JsonProperty("$age")
        private int age;

        @Override
        public String toString() {
            return "User{" +
                   "username='" + username + "'" + ", age=" + age +
                   '}';
        }

        public String getUsername() { return username; }
        public void setUsername(String username) { this.username = username; }
        public int getAge() { return age; }
        public void setAge(int age) { this.age = age; }
    }

    public static class UserWrapper {
        private User user;
        public User getUser() { return user; }
        public void setUser(User user) { this.user = user; }
    }

    public static void main(String[] args) {
        // The JSON string with dollar signs, correctly escaped for a Java String literal.
        String jsonString = "{\"user\":{\"$username\":\"sumika\",\"$age\":16}}";
        System.out.println("Original JSON String: " + jsonString);

        ObjectMapper objectMapper = new ObjectMapper();

        try {
            UserWrapper wrapper = objectMapper.readValue(jsonString, UserWrapper.class);
            System.out.println("\nParsing successful!");

            User parsedUser = wrapper.getUser();
            if (parsedUser != null) {
                System.out.println("Parsed User Object: " + parsedUser.toString());
                System.out.println("------------------------------------");
                System.out.println("Username from object: " + parsedUser.getUsername());
                System.out.println("Age from object: " + parsedUser.getAge());
            } else {
                System.out.println("Failed to parse the user object.");
            }

        } catch (JsonProcessingException e) {
            System.err.println("Error parsing JSON string!");
            e.printStackTrace();
        }
    }
}
