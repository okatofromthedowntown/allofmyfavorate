import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonDollarSignParser {

    public static class Detail {
        @JsonProperty("$sex")
        private int sex;

        @JsonProperty("$email")
        private String email;

        @Override
        public String toString() {
            return "Detail{" +
                   "sex=" + sex +
                   ", email='" + email + '\'' +
                   '}';
        }

        public int getSex() { return sex; }
        public void setSex(int sex) { this.sex = sex; }
        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }
    }

    public static class User {
        @JsonProperty("$username")
        private String username;

        @JsonProperty("$age")
        private int age;

        @JsonProperty("$detail")
        private Detail detail;

        @Override
        public String toString() {
            return "User{" +
                   "username='" + username + "'" +
                   ", age=" + age +
                   ", detail=" + detail +
                   '}';
        }

        public String getUsername() { return username; }
        public void setUsername(String username) { this.username = username; }
        public int getAge() { return age; }
        public void setAge(int age) { this.age = age; }
        public Detail getDetail() { return detail; }
        public void setDetail(Detail detail) { this.detail = detail; }
    }

    public static class UserWrapper {
        private User user;
        public User getUser() { return user; }
        public void setUser(User user) { this.user = user; }
    }

    public static void main(String[] args) {
        String jsonString = "{\"user\":{\"$username\":\"name123\",\"$age\":16, \"$detail\":{\"$sex\":0, \"$email\":\"test@test.jp\"}}}";
        System.out.println("Original JSON String: " + jsonString);

        ObjectMapper objectMapper = new ObjectMapper();

        try {
            UserWrapper wrapper = objectMapper.readValue(jsonString, UserWrapper.class);
            System.out.println("\nParsing successful!");

            User parsedUser = wrapper.getUser();
            if (parsedUser != null) {
                System.out.println("Parsed User Object: " + parsedUser.toString());
                System.out.println("------------------------------------");
                System.out.println("Username: " + parsedUser.getUsername());
                System.out.println("Age: " + parsedUser.getAge());
                if (parsedUser.getDetail() != null) {
                    System.out.println("Detail Sex: " + parsedUser.getDetail().getSex());
                    System.out.println("Detail Email: " + parsedUser.getDetail().getEmail());
                }
            } else {
                System.out.println("Failed to parse the user object.");
            }

        } catch (JsonProcessingException e) {
            System.err.println("Error parsing JSON string!");
            e.printStackTrace();
        }
    }
}